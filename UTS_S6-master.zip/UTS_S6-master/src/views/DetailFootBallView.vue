<script setup>
import Detail from '../components/DetailFootball.vue'
</script>
<template>
    <Detail/>
</template>