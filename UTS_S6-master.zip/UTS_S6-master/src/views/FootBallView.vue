<script setup> import Club from '../components/FootBall.vue'</script>
<template> <Club/> </template>